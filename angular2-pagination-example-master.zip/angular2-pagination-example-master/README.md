# angular2-pagination-example

Angular 2 - Pagination Example with Logic like Google

To see a demo and further details go to http://jasonwatmore.com/post/2016/08/23/angular-2-pagination-example-with-logic-like-google
